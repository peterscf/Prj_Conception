%% M�thode LL
% Programme Matlab7.01R14 SP2 - RF Toolbox
% Jean-Daniel ARNOULD, Pierre RAPUC, Michel GALLITRE, Pardis SAEBI le 08.06.2005
% Ce programme est bas� sur la mesure de 2 lignes de longueur diff�rente
% ayant la m�me imp�dance caract�ristique [Hernandez03]
% Le de-embedding de plots n'est pas n�cessaire � condition qu'ils soient
% identiques entre les 2 lignes

%% Destruction des figures et des variables
% -------------------------------------------------------------------------
close all;
clear all;

%% R�cup�ration des param�tres S de la ligne au format Touchstone
% -------------------------------------------------------------------------
measured_data1 = read(rfdata.data, 'ligne_5mm.s2p'); % ligne de 5 mm
measured_data2 = read(rfdata.data, 'ligne_1mm.s2p'); % ligne de 1 mm
%% R�cup�ration des longueurs de lignes en m�tres
% -------------------------------------------------------------------------
L1=5*1E-3;      % longueur en m�tres de la grande ligne
L2=1*1E-3;      % longueur en m�tres de la petite ligne

%% Transformations matricielles ne n�cessitant pas la connaissance de
%% l'imp�dance Z0 de mesure
% -------------------------------------------------------------------------
t1_params=s2t(measured_data1.S_Parameters); 
t2_params=s2t(measured_data2.S_Parameters); 

%% Valeurs propres
% -------------------------------------------------------------------------
[n,k,m] = size(t1_params); % taille de la matrice t1
T_params = zeros(n,k,m); % initialisation

for i=1:m
T_params(:,:,i)=t1_params(:,:,i)*inv(t2_params(:,:,i));
t11(i)=T_params(1,1,i);
t12(i)=T_params(1,2,i);   
t21(i)=T_params(2,1,i);
t22(i)=T_params(2,2,i);
end

%% Solution de l'�quation du second ordre
% -------------------------------------------------------------------------
delta=(t22-t11).^2+4.*t21.*t12; % d�terminant
lambda_1=(-(t22-t11)+sqrt(delta))./(2*t21);                  %=b
lambda_2=(-(t22-t11)-sqrt(delta))./(2*t21);                  %=a/c

%% lorsque am/cm =lambda_2 et bm=lambda_1
% -------------------------------------------------------------------------
sol_1=(lambda_2-lambda_1)./(lambda_2.*t22+lambda_1.*lambda_2.*t21-lambda_1.*t11-t12);

%% Boucle permettant de choisir soit l'une soit l'autre solution en fonction
%% du crit�re fondamental abs(sol)<1
% -------------------------------------------------------------------------
lambda=zeros(length(sol_1),1);
for i=1:1:length(sol_1)
    if abs(sol_1(i))<1
        lambda(i)=sol_1(i);
     else lambda(i)=1./sol_1(i);
        end	
end
    
%% Construction de la constante de propagation
% -------------------------------------------------------------------------
f = measured_data1.Freq;
alpha=abs(real((1/(L2-L1))*log((lambda))));      % att�nuation
beta=abs((1/(L2-L1))*unwrap(imag(log(lambda)))); % d�phasage d�roul�
gamma=alpha+1i*beta; %  Constante de propagation

%% V�rification avec la trace de la matrice
% -------------------------------------------------------------------------
figure()
subplot(211);
plot(f ,abs(t11+t22),'b');
title('|Trace(T)|')
ylabel('|Trace(T)|')
grid;
hold on
plot(f ,abs(2*cosh(gamma*(L2-L1))),'r');
hold off;
subplot(212);
plot(f ,phase(t11'+t22')*180/pi,'b');
hold on
plot(f*1 ,phase((2*cosh(gamma*(L2-L1)))')*180/pi,'r');
title('\phi(Trace(T))')
ylabel('\phi(Trace(T))')
xlabel('Fr�quence (GHz)')
grid;
hold off;

%% Enregistrement de alpha et beta dans un fichier S2P au format Touchstone
% -------------------------------------------------------------------------
for i=1:length(f)
    sauv((3*i)-2)=f(i);
    sauv((3*i)-1)=real(gamma(i));
    sauv((3*i))=imag(gamma(i));
end
ww=cd;
[newfile,newpath] = uiputfile('alpha_beta.s2p','Sauvegarde de la constante de propagation',100,100);
cd(newpath);
fid = fopen(newfile,'w');
fprintf(fid,'! freq alpha (Np/m)=real(S11) beta(1/m)=imag(S11) 0 0 0 0 0 0\n# Hz S RI R 50\n');
fprintf(fid,'%12.8f %12.10f %12.10f 0 0 0 0 0 0\n',sauv);
fclose(fid);
cd(ww);








