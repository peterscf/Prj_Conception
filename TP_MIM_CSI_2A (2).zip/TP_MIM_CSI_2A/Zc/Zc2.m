%% Imp�dance caract�ristique de ligne deembeddee de ses plots
% Programme bas� sur sqrt(B/C) de la matrice chaine
% Programme Matlab 7.0.1R14 SP2 - Toolbox RF
% Jean-Daniel ARNOULD le 10 mars 2005


%% Destruction des figures et des variables
% -------------------------------------------------------------------------
close all
clear variables

%% R�cup�ration des param�tres S de la ligne au format Touchstone
% -------------------------------------------------------------------------
measured_data = read(rfdata.data, 'ZCR1_os.s2p'); % ligne deembedd�e
freq = measured_data.Freq;

%% Visualisation des donn�es 
% -------------------------------------------------------------------------
figure
smith(measured_data, 's11','s21','s12','s22');   % Plot Sij on smith chart

z0 = measured_data.Z0; % Imp�dance de mesure
abcd_params=s2abcd(measured_data.S_Parameters,z0); % Transformation de S en ABCD (Z0 est demande)
[n,k,m] = size(abcd_params); % Taille de la matrice ABCD


for i=1:m  
Zc(i)=sqrt(abcd_params(1,2,i)/abcd_params(2,1,i));
end
Zcr=real(Zc);
Zci=imag(Zc);

%% Enregistrement de alpha et beta dans un fichier S2P au format Touchstone
% -------------------------------------------------------------------------
for i=1:length(freq)
    sauv((3*i)-2)=freq(i);
    sauv((3*i)-1)=real(Zc(i));
    sauv((3*i))=imag(Zc(i));
end
ww=cd;
[newfile,newpath] = uiputfile('Zc.s2p','Sauvegarde de l''imp�dance caract�ristique',100,100);
cd(newpath);
fid = fopen(newfile,'w');
fprintf(fid,'! freq Zcr=real(Zc) Zci=imag(Zc) 0 0 0 0 0 0\n# Hz S RI R 50\n');
fprintf(fid,'%12.8f %12.10f %12.10f 0 0 0 0 0 0\n',sauv);
fclose(fid);
cd(ww);


%% Visualisation de l'imp�dance caract�ristique
% -------------------------------------------------------------------------
figure
plot(freq/1E9,real(Zc),'-green',freq/1E9,imag(Zc),'-red')
xlabel('fr�quence [GHz]')
ylabel('Zc')
legend('Z_{cr}','Z_{ci}')
grid on;

A=abcd_params(1,1,:);
B=abcd_params(1,2,:);
C=abcd_params(2,1,:);
D=abcd_params(2,2,:);

A=reshape(A,1,size(freq,1));
B=reshape(B,1,size(freq,1));
C=reshape(C,1,size(freq,1));
D=reshape(D,1,size(freq,1));

Zc = sqrt(B/C);
Gam= acos(A/L);