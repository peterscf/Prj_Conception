S_recup = read(rfdata.data,'dst_vandamme.s2p');

freq1 = get(S_recup,'Freq');
Z01 = get(S_recup,'Z0');

Y = s2y(S_recup.S_Parameters,Z01);
Y11 = Y(1,1,:);
Y12 = Y(1,2,:);
Y21 = Y(2,1,:);
Y22 = (1*Y(2,2,:));

Y1 = Y11 + Y12;
Y2 = Y22 + Y21;
Z3 = -1/Y12;

Rmim = real(Z3);
plot(freq,Rmim);