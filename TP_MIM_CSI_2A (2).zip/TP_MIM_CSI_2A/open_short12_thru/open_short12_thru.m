%% OPEN SHORT12 THRU
% Programme Matlab7.01R14 SP2 - RF Toolbox
% Jean-Daniel ARNOULD, Michel GALLITRE le 08.06.2005
% Ce programme est bas� sur la m�thode de deembedding de Vandamme
% [Vandamme01] qui utilise 4 standards apr�s la calibration.

% Effacement des variables et des graphes :
clear all
close all

%% R�cup�ration des donn�es � l'aide des fichiers Touchstone de mesures : 
% -------------------------------------------------------------------------
DUT_S = read(rfdata.data,'zcm1b.s2p');%a remplacer par la capa � �tudier
open_S = read(rfdata.data,'zcm6a_open.s2p');
short1_S = read(rfdata.data,'zcm4a_short.s2p');
short2_S = read(rfdata.data,'zcm4a_short.s2p');
thru_S = read(rfdata.data,'thru.s2p');
%DUT_seul_S = read(rfdata.data,'dst_seul.s2p');

%% R�cuperation de la fr�quence et de l'imp�dance de mesure Z0 :
% -------------------------------------------------------------------------
freq = get(DUT_S,'Freq');
Z0 = get(DUT_S,'Z0');

%% Transformation des param�tres S mesur�s en param�tres Y :
% -------------------------------------------------------------------------
DUT_y = s2y(DUT_S.S_Parameters,Z0);
open_y = s2y(open_S.S_Parameters,Z0);
short1_y = s2y(short1_S.S_Parameters,Z0);
short2_y = s2y(short2_S.S_Parameters,Z0);
thru_y = s2y(thru_S.S_Parameters,Z0);

%% Calcul des �l�ments Gi et Zi (i=1,2,3) des sch�mas �quivalents des
%% structures Open, Short1, Short2 et Thru :
% -------------------------------------------------------------------------

% D�finition des structures G12, G3 et Z123 qui seront
% compos�s des �l�ments Gi et Zi 
G12(1,1,:) = open_y(1,1,:) + open_y(1,2,:);
G12(1,2,:) = 0;
G12(2,1,:) = 0;
G12(2,2,:) = open_y(2,2,:) + open_y(1,2,:);

Z1 = 0.5*(-1./thru_y(1,2,:) + 1./(short1_y(1,1,:)-G12(1,1,:)) - 1./(short2_y(2,2,:)-G12(2,2,:)));
Z2 = 0.5*(+1./thru_y(1,2,:) + 1./(short1_y(1,1,:)-G12(1,1,:)) + 1./(short2_y(2,2,:)-G12(2,2,:))); 
Z3 = 0.5*(+1./thru_y(1,2,:) + 1./(short1_y(1,1,:)-G12(1,1,:)) + 1./(short2_y(2,2,:)-G12(2,2,:)));

Z123(1,1,:) = Z1 + Z3; 
Z123(1,2,:) = Z3;
Z123(2,1,:) = Z3; 
Z123(2,2,:) = Z2 + Z3; 

G3(1,1,:) = 1./(1./thru_y(1,2,:)-1./open_y(1,2,:));
G3(1,2,:) = -G3(1,1,:);
G3(2,1,:) = -G3(1,1,:);
G3(2,2,:) = G3(1,1,:);

%% Op�rations de de-embedding : 
% -------------------------------------------------------------------------
% Etape 1 : �limination de G1 et G2 :
Ya = DUT_y - G12;

% Etape 2 : �limination de Z1, Z2 et Z3 :
Za = y2z(Ya);
Zb = Za -Z123;

% Etape 3 : �limination de G3 (couplage entre les ports 1 et 2) :
Yb = z2y(Zb);
Ydeemb = Yb -G3;

% Z_imag=imag(1./Ydeemb(1,2,:));
% Z_imag=reshape(Z_imag, size(freq,1));
% 
% Z_real=real(1/Ydeemb(1,2,:));
% Z_real=reshape(Z_real, size(freq,1));

Y11 = Ydeemb(1,1,:);
Y12 = Ydeemb(1,2,:);
Y21 = Ydeemb(2,1,:);
Y22 = Ydeemb(2,2,:);

Y11=reshape(Y11,1,size(freq,1));
Y12=reshape(Y12,1,size(freq,1));
Y21=reshape(Y21,1,size(freq,1));
Y22=reshape(Y22,1,size(freq,1));

Y1 = Y11 + Y12;
Y2 = Y22 + Y12;
Z_3 = -1./Y12;


Rmim = real(Z_3);
plot(freq,real(Z_3));
Rmim = mean(Rmim);
hold on;


fci = find(imag(Z_3)>0,1);
freq1= freq';
Lmim = imag(Z_3(:,fci:length(Z_3)))./(2*pi()*freq1(:,fci:length(freq1)));
figure;
plot(freq,imag(Z_3));
title('Partie imaginaire de Z3 d��embed�e et reconstruite');
Lmim = mean(Lmim(length(Lmim)-10),length(Lmim))
Cmim = 1./(imag(Z_3(:,1:fci).*(2*pi()*freq1(:,1:fci))));
Cmim = -mean(Cmim(1),length(Cmim)-60)
hold on;
plot(freq,Lmim*2*pi*freq - 1./(Cmim*2*pi*freq));

fc=1/(2*pi*sqrt(Lmim*Cmim));

Rsub1=1./real(Y1);
figure;
plot(freq,Rsub1);
Rsub1=Rsub1(40:115);
title('Rsub1');
Rsub1=mean(Rsub1);
figure;
Csub1=(imag(Y1)./(2*pi*freq1));
plot(freq,Csub1);
title('Csub1');

Rsub2=1./real(Y2);
figure;
plot(freq,Rsub2);
title('Rsub2');
Rsub2=mean(Rsub2);

figure;
Csub2=(imag(Y2)./(2*pi*freq1));
plot(freq,Csub2);
title('Csub2');

Q=-imag(Z_3)./real(Z_3);
Q2 = Q'
figure;
plot(freq,Q);
title('Facteur de qualite');

%% Transformation finale en param�tres S:
% -------------------------------------------------------------------------
DUT_S_deemb = y2s(Ydeemb,Z0);

%% V�rification de la validit� de notre proc�dure : 
% -------------------------------------------------------------------------
% ratio1_min >> 1 et ratio2_min >> 1
for i=1:length(freq),
ratio1(i) = abs((1/G3(1,1,i)) + Z1(1,1,i))./abs(Z3(1,1,i));
ratio2(i) = abs((1/G3(1,1,i)) + Z2(1,1,i))./abs(Z3(1,1,i));
end
% v�rification num�rique ratio >> 1 :
ratio_min=min(min(ratio1),min(ratio2))

%% Sauvegarde des r�sultats : 
% -------------------------------------------------------------------------
DUT_S_deemb_data = rfdata.data('Z0',Z0,...
                  'S_Parameters',DUT_S_deemb,...
                  'Freq',freq);
ww=cd;
[newfile,newpath] = uiputfile('dst_vandamme.s2p','Sauvegarde du fichier deembedd�',100,100);
cd(newpath);              
ecriture=write(DUT_S_deemb_data,newfile);
cd(ww);
%% Comparaisons graphiques (courbes en dB) :
% -------------------------------------------------------------------------

% Transmission :
figure
lin1 = smith(DUT_S,'s21');
set(lin1,'Color','b');
hold on
%lin2 = smith(DUT_seul_S,'s21');
%set(lin2,'Color','r');
hold on
lin3 = smith(DUT_S_deemb_data,'s21');
set(lin3,'Color','g');
legend([lin1,lin3],'S21 DST non deembedd�','S21 deembedd�')
hold off

% R�flexion :
figure
lin1 = smith(DUT_S,'s11');
set(lin1,'Color','b');
hold on
%lin2 = smith(DUT_seul_S,'s11');
%set(lin2,'Color','r');
hold on
lin3 = smith(DUT_S_deemb_data,'s11');
set(lin3,'Color','g');
legend([lin1,lin3],'s11 DST non deembedd�','s11 deembedd�')
hold off

